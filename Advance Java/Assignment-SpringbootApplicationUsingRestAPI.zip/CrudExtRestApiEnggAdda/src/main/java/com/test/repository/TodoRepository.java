package com.test.repository;


import com.test.model.Todo;

//public interface TodoRepository extends JpaRepository<Todo, Integer> {
//	// You can add custom query methods here if needed
//	// For example:
//	// List<Todo> findByTitle(String title);
//}