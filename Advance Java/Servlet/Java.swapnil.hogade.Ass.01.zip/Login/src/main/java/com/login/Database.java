//package com.login;
//
//import javax.annotation.processing.*;
//@webServlet("/Register")
//public class Database {
//
//	public static void main(String[] args) {
//
//
//	}
//
//}
