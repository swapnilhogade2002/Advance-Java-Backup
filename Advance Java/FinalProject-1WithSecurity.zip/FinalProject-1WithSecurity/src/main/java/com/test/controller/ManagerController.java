package com.test.controller;

import java.io.IOException;
import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.test.entity.Employee;
import com.test.entity.EmployeeInfo;
import com.test.repository.EmployeeInfoRepo;
import com.test.repository.EmployeeRepo;
import com.test.service.EmployeeInfoService;
import com.test.service.EmployeeServiceImpl;

import jakarta.servlet.http.HttpServletResponse;

@Controller
@RequestMapping("/manager")
public class ManagerController {

	@Autowired
	private EmployeeRepo employeeRepo;

	@Autowired
	private EmployeeServiceImpl employeeServiceImpl;

	@Autowired
	private EmployeeInfoService employeeInfoService;
	
	@Autowired
	private EmployeeInfoRepo employeeInfoRepo;

	@ModelAttribute
	public void commanUser(Principal p, Model m) {
		if (p != null) {
			String email = p.getName();
			Employee employee = employeeRepo.findByEmail(email);
			m.addAttribute("employee", employee);

		}
	}

	// UI data
//	@GetMapping("/view")
//	public String listEmployeeInfos(Model model) {
//		List<EmployeeInfo> employeeInfoList = employeeInfoService.getAllEmployee();
//		System.out.println(employeeInfoList);
//		model.addAttribute("employeeInfoList", employeeInfoList);
//		return "manager-profile";
//	}

	@GetMapping("/profile")
	public String profile(Model model) {
//		
		List<EmployeeInfo> employeeInfoList = employeeInfoService.getAllEmployee();
		System.out.println(employeeInfoList);
		model.addAttribute("employeeInfoList", employeeInfoList);
		return "manager-profile";
	}

//	download

//  download pdf
	@GetMapping
	public List<Employee> getAllEntities() {
		return employeeServiceImpl.getAllEntities();
	}

	@GetMapping("/download")
	public void downloadEntities(HttpServletResponse response) throws IOException {
		List<Employee> entities = employeeServiceImpl.getAllEntities();

		// Set the content type and headers for the response
		response.setContentType("text/csv");
		response.setHeader("Content-Disposition", "attachment; filename=entities.csv");

		// Write the data to the response output stream
		// You can use a library like OpenCSV for better CSV handling
		for (Employee entity : entities) {
			response.getWriter().write(entity.toString()); // Customize based on your entity structure
			response.getWriter().write("\n");
		}
	}

//	CRUD on manager UI
//
////	add employee
//	@GetMapping("/form")
//	public String showForm(Model model) {
//		model.addAttribute("EmployeeInfo", new EmployeeInfo());
//		return "employeeForm";
//	}
//
//	@PostMapping("/form")
//	public String submitForm(@ModelAttribute EmployeeInfo employee) {
//		employeeInfoRepo.save(employee);
//		return "redirect:/employee/profile";
//	}
//
////	edit
//	@GetMapping("/edit/{id}")
//	public String editForm(@PathVariable Long id, Model model) {
//		EmployeeInfo employeeInfo = employeeInfoService.getEmployeeInfo(id);
//		model.addAttribute("EmployeeInfo", employeeInfo);
//		return "employeeEditForm";
//	}
//
//	@PostMapping("/edit")
//	public String submitEditForm(@ModelAttribute EmployeeInfo employee) {
//		employeeInfoService.saveEmployeeInfo(employee);
//		return "redirect:/employee/profile";
//	}
//
////	delete
//	@GetMapping("/delete/{id}")
//	public String deleteEmployeeInfo(@PathVariable Long id) {
//		employeeInfoService.deleteEmployeeInfo(id);
//		return "redirect:/employeeform/form";
//	}
//
////	view 
//	@GetMapping("/view/{id}")
//	public String viewEmployeeInfo(@PathVariable Long id, Model model) {
//		EmployeeInfo employeeInfo = employeeInfoService.getEmployeeInfo(id);
//		model.addAttribute("EmployeeInfo", employeeInfo);
//		return "employeeView";
//	}

}
