package com.test.controller;

import java.io.IOException;
import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.test.entity.Employee;
import com.test.repository.EmployeeRepo;
import com.test.service.EmployeeService;
import com.test.service.EmployeeServiceImpl;

import jakarta.servlet.http.HttpServletResponse;

@Controller
@RequestMapping("/employee")
public class EmployeeController {
	@Autowired
	private EmployeeRepo employeeRepo;

	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	private EmployeeServiceImpl employeeServiceImpl;

	@ModelAttribute
	public void commanUser(Principal p, Model m) {
		if (p != null) {
			String email = p.getName();
			Employee employee = employeeRepo.findByEmail(email);
			m.addAttribute("employee", employee);

		}
	}

//	@GetMapping("/profile")
//	public String profile() {
//		return "profile";
//	}

	@GetMapping("/profile")
	public String showProfile(Model model) {
		// Assuming you have an Employee object in your application
		Employee employee = new Employee();
		model.addAttribute("employee", employee);
		return "profile";
	}


}
