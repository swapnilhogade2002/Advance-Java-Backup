package com.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalProject1WithSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
