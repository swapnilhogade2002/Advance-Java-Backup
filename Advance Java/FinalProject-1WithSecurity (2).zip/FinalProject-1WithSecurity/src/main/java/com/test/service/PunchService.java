package com.test.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.entity.EmployeeInfo;
import com.test.repository.EmployeeInfoRepo;

import jakarta.persistence.EntityNotFoundException;

@Service
public class PunchService {

    @Autowired
    private EmployeeInfoRepo employeeRepository;

    public void punchIn(Long userId) {
        // Get employee by userId (you may want to add error handling)
        EmployeeInfo employee = employeeRepository.findById(userId).orElseThrow(EntityNotFoundException::new);

        // Set punch-in time
        employee.setPunchInTime(LocalDateTime.now());

        // Save the updated employee
        employeeRepository.save(employee);
    }

    public void punchOut(Long userId) {
        // Get employee by userId (you may want to add error handling)
        EmployeeInfo employee = employeeRepository.findById(userId).orElseThrow(EntityNotFoundException::new);

        // Set punch-out time
        employee.setPunchInTime(LocalDateTime.now());

        // Save the updated employee
        employeeRepository.save(employee);
    }
}
