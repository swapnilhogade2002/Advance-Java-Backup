package com.test.service;

import com.test.entity.EmployeeInfo;
import com.test.repository.EmployeeInfoRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeInfoServiceImpl implements EmployeeInfoService {

	@Autowired
	private EmployeeInfoRepo employeeInfoRepo;

	@Override
	public EmployeeInfo saveEmployeeInfo(EmployeeInfo employee) {
		return employeeInfoRepo.save(employee);
	}

	@Override
	public EmployeeInfo getEmployeeInfo(Long id) {
		Optional<EmployeeInfo> employeeInfoOptional = employeeInfoRepo.findById(id);
		return employeeInfoOptional.orElse(null);
	}

	@Override
	public void deleteEmployeeInfo(Long id) {
		employeeInfoRepo.deleteById(id);
	}

	@Override
	public List<EmployeeInfo> getAllEmployee() {
		return employeeInfoRepo.findAll();
	}

}