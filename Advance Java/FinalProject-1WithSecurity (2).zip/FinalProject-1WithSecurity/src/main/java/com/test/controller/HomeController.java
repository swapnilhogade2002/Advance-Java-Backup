package com.test.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.test.entity.Employee;
import com.test.repository.EmployeeRepo;
import com.test.service.EmployeeService;

import jakarta.servlet.http.HttpSession;

@Controller
public class HomeController {

	@Autowired
	EmployeeService employeeService;

	@Autowired
	private EmployeeRepo employeeRepo;

	@ModelAttribute
	public void commanUser(Principal p, Model m) {
		if (p != null) {
			String email = p.getName();
			Employee employee = employeeRepo.findByEmail(email);
			m.addAttribute("employee", employee);

		}

	}

	@GetMapping("/")
	public String index() {
		return ("index");
	}

	@GetMapping("/register")
	public String register() {
		return ("register");
	}

	@GetMapping("/login")
	public String signin() {
		return ("login");
	}

//	@GetMapping("/employee/profile")
//	public String profile(Principal p, Model m) {
//		String name = p.getName();
//		Employee employee = employeeRepo.findByEmail(name);
//		m.addAttribute("employee", employee);
//		return ("profile");
//	}
//
//	@GetMapping("/employee/home")
//	public String home() {
//		return ("home");
//	}

//	save user

	@PostMapping("/saveUser")
	public String saveUser(@ModelAttribute Employee Employee) {
		Employee saveEmployee = employeeService.saveEmployee(Employee);
		if (saveEmployee != null) {
			System.out.println("Succesfully register!");
			// session.setAttribute("msg", "Succesfully register!");
		} else {
			System.out.println("Register once again.");
			// session.setAttribute("msg", "error in registration!");
		}

		System.out.println(Employee);
		return "redirect:/register";
	}

}
