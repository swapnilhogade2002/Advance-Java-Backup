package com.test.controller;

import java.io.IOException;
import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.test.entity.Employee;
import com.test.entity.EmployeeInfo;
import com.test.repository.EmployeeInfoRepo;
import com.test.repository.EmployeeRepo;
import com.test.service.EmployeeInfoService;
import com.test.service.EmployeeService;
import com.test.service.EmployeeServiceImpl;


import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/employee")
public class EmployeeController {
	@Autowired
	private EmployeeRepo employeeRepo;

	@Autowired
	private EmployeeService employeeService;

	@Autowired
	private EmployeeServiceImpl employeeServiceImpl;
	@Autowired
	private EmployeeInfoRepo employeeInfoRepo;

	@Autowired
	private EmployeeInfoService employeeInfoService;

//	@Autowired
//	private PunchService punchService;

	@ModelAttribute
	public void commanUser(Principal p, Model m) {
		if (p != null) {
			String email = p.getName();
			Employee employee = employeeRepo.findByEmail(email);
			m.addAttribute("employee", employee);

		}
	}

//	@GetMapping("/profile")
//	public String profile() {
//		return "profile";
//	}

	@GetMapping("/profile")
	public String showProfile(Model model) {
		// Assuming you have an Employee object in your application
		Employee employee = new Employee();
		model.addAttribute("employee", employee);
		return "profile";
	}

//	add employee
	@GetMapping("/form")
	public String showForm(Model model) {
		model.addAttribute("EmployeeInfo", new EmployeeInfo());
		return "employeeForm";
	}

	@PostMapping("/form")
	public String submitForm(@Valid @ModelAttribute EmployeeInfo employee) {
		employeeInfoRepo.save(employee);
		return "redirect:/employee/profile";
	}

//	punch service
//	@PostMapping("/punch")
//	public String punch(@RequestParam("userId") Long userId, @RequestParam("action") String action) {
//		if ("punchIn".equals(action)) {
//			punchService.punchIn(userId);
//		} else if ("punchOut".equals(action)) {
//			punchService.punchOut(userId);
//		}
//
//		// Redirect to the employee page or another appropriate page
//		return "redirect:/employee/profile";
//	}
	
//	add employee
	@GetMapping("/attendence")
	public String employeeAttendence(Model model) {
		model.addAttribute("EmployeeInfo", new EmployeeInfo());
		return "attendence1";
	}



}
