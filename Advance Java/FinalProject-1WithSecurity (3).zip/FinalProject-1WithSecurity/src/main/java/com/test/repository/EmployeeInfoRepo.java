package com.test.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.test.entity.EmployeeInfo;

@Repository
public interface EmployeeInfoRepo extends JpaRepository<EmployeeInfo, Long> {
	// You don't need to declare findById here, it's already provided by
	// JpaRepository
	
//	total count gender-male
	long countByGender(String gender);
	
//	total count married employee
	long countByMaritalStatus(String maritalStatus);
	
//	total count Bachelors degress
	long countByEducationLevel(String educationLevel);

	
	
}