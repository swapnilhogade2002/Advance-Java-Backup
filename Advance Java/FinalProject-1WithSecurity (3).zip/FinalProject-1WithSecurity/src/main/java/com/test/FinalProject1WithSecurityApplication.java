package com.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalProject1WithSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinalProject1WithSecurityApplication.class, args);
	}

}
