package com.test.service;

import java.util.List;

import com.test.entity.Employee;
import com.test.entity.EmployeeInfo;

public interface EmployeeInfoService {

	public EmployeeInfo saveEmployeeInfo(EmployeeInfo employee);

	EmployeeInfo getEmployeeInfo(Long id);

	void deleteEmployeeInfo(Long id);

//	UI data
	List<EmployeeInfo> getAllEmployee();

	long getTotalCount();

    long getCountByGender(String gender);
    
    long getCountByMaritalStatus(String maritalStatus);
    
    long getCountByEducationLevel(String educationLevel);



}
