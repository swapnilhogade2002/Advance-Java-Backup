#taking base and height of triangle
base=float(input("Enter a base of a triangle: "))
height=float(input("Enter height of triangle: "))

#calculating area and print
area=0.5*height*base
print("Area of triangle: ", area)
