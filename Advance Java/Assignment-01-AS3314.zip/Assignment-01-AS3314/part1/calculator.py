#taking a number from user
first_number = float(input("Enter first number: "))
secound_number = float(input("Enter secound number: "))

#showing result
print("********Calculator**********")

addition=first_number+secound_number
print("Addition of number: ",addition)

substraction =first_number-first_number
print("Substraction of number: ",substraction)

multiplication=first_number*first_number
print("Multiplication of number: ",multiplication)

division=first_number/first_number
print("Division of number: ",division)