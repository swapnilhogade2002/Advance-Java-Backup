#swapping function
def swap_case(input_string):
    return input_string.swapcase()

#input of string
manipulate_string=input("Enter a string: ")

#result
result=swap_case(manipulate_string)
print("swapping of String: ", result)