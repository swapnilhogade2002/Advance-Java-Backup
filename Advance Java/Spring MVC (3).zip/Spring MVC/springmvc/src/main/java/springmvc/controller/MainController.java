package springmvc.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.view.RedirectView;

import springmvc.dao.ProductDao;
import springmvc.model.Product;

@Controller
public class MainController {
 
	@Autowired
	private ProductDao productDao;
	
	
	@RequestMapping("/index")
	public String Home(Model m) {
		
		List<Product> products = productDao.getProducts();
		m.addAttribute("products", products);
		return "index";
	}
	
//	add product
	@RequestMapping("/add-product")
	public String addProduct(Model m) {
		m.addAttribute("title", "Add Product");
		return "add-product-form";
	}

//	handling add product form
	@RequestMapping(value="/handle-product" , method=RequestMethod.POST)
	public String handleProduct(@ModelAttribute Product product , HttpServletRequest request ) {
		System.out.println(product);
		productDao.createProduct(product);
//		RedirectView redirectView = new RedirectView();
//		redirectView.setUrl(request.getContextPath()+"/index");
		return  "redirect:/index";
	}
	
//	delete product
	@RequestMapping("/delete/{productId}")
	public String deleteProduct(@PathVariable("productId") int productId ,HttpServletRequest request) {
		this.productDao.deleteProduct(productId);
//		RedirectView redirectView  = new RedirectView();
//		redirectView.setUrl(request.getContextPath()+"/");
		return  "redirect:/index";
		
	}
	
//	update product
	@RequestMapping("/update/{productId}")
	public String updateProduct(@PathVariable("productId") int pid, Model model) {
		Product product = this.productDao.getProduct(pid);
		model.addAttribute("product",product);
		System.out.println(product);
		return "update-form";
		
		
	}
	
}
